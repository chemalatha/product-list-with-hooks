import React from 'react';

const Footer = ()=>{
    return(
        <header>
            <h2>&copy;All Images are copyrighted</h2>
        </header>
    )
}

export default Footer;