import React from 'react';

const Header = ()=>{
    return(
        <header>
            <h2>Product List App with hooks</h2>
        </header>
    )
}

export default Header;